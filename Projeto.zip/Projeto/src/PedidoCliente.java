import java.util.Scanner;
//2. Classe PedidoCliente (implementa Pedido): possiveis atributos: lista_pizzas; Pedido.
public class PedidoCliente {

    public static void mostrarPedido() {
        Scanner pedidos = new Scanner(System.in);

        // Armazenar o pedido em uma variavel

        String pedido;

        System.out.println("Digite o seu pedido aqui:");
        pedido = pedidos.nextLine();

        System.out.println("\nSeu Pedido "+ pedido +" foi cadastrado com Sucesso\n");
    }
}
