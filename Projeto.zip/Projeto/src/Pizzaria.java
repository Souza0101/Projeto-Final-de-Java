//5. Classe Pizzaria: possivel metodo: receberPedido(Pedido pedido).

import java.util.Scanner;

public class Pizzaria {

    public static void main(String[] args) {

        // cadastrar o nome do Cliente
        Usuario.CadastrarCliente();

        // Mostrar os sabores das Pizzas disponíveis
        Pizza.mostrarSabores();

        // Mostrar os tamanhos das Pizzas disponíveis
        Pizza.mostrarTamanhos();

        // Mostrar as Bebidas disponiveis
        Bebida.mostrarBebidas();

        // Mostrar o Pedido do Cliente
        PedidoCliente.mostrarPedido();

        //fim do pedido e pagamento
        Cliente.direcionarCliente();
    }
}