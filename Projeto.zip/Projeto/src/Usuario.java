import java.util.Scanner;

//3. Classe abstrata Usuario: possiveis atributos: nome; endereco. possivel metodo abstrato: fazerPedido().
public abstract class Usuario {

    public static void CadastrarCliente() {

        //cadastro dos clientes
        String nomes;
        String enderecos;

        Scanner nome = new Scanner(System.in);

        System.out.println("Digite o seu nome:");
        nomes = nome.nextLine(); //pegar tudo o que for escrito na resposta e salvar em 'nomes'

        Scanner endereco = new Scanner(System.in);

        System.out.println(nomes+" Digite o seu endereço de entrega:");
        enderecos = endereco.nextLine();
        System.out.println("");
    }
}
