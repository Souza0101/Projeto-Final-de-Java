public class Bebida{

    // Atributo para guaradar os sabores de bebida
    private static String[] Bebidas = {
           "Refrigerante", "Cerveja", "Vinho", "Água com gás", "Chá gelado", "Suco de frutas",
            "Limonada","chá gelado", "coquetel", "Limonada de Morango"};

    // Método para exibir os sabores disponíveis
    public static void mostrarBebidas() {
        System.out.println("\nNós temos os seguintes sabores de Bebidas disponíveis:");

        for (String Bebidas : Bebidas) {
            System.out.println(Bebidas);
        }
    }
}