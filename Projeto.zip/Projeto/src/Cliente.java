//4. Classe Cliente (herda de Usuario): possivel metodo: fazerPedido() [Que cria um novo PedidoCliente()].
import java.util.Scanner;
public class Cliente extends Usuario{

    public static void direcionarCliente() {

        Scanner direcionamento = new Scanner(System.in);

        String direcionar;

        System.out.println("Seu pedido ficará pronto em uma média de 50 mins, qual seria sua forma de pagamento?");
        direcionar = direcionamento.nextLine();

        System.out.println(" A Pizzaria OAK agradece a Preferencia.");
    }
}
