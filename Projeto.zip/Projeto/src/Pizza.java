// 1. Classe Pizza: possíveis atributos: tamanho; ingredientes.
public class Pizza {

    // Atributo para armazenar os sabores disponíveis
    private static String[] sabores = {
            "Mussarela", "Escarola", "Marguerita", "Atum", "Romana",
            "Quatro queijos", "Peperoni", "Calabresa", "Napolitana", "Brócolis",
            "Siciliana", "Lombinho", "Estrogonofe de Carne", "Estrogonofe de Frango",
            "Portuguesa", "Palmito", "Bacon", "Mista", "Califórnia", "Frango",
            "Frango com Catupiry", "Espanhola", "Parmegiana", "Chocolate",
            "Prestígio", "Romeu e Julieta", "Sensação", "Sorvete", "Paçoca",
            "Nutella com Morango"
    };

    // Atributo para armazenar os tamanhos disponíveis
    private static String[] tamanhos = {"1 metro", "Meio Metro", "Grande", "Média", "Pequena"};

    // Método para exibir os sabores disponíveis
    public static void mostrarSabores() {
        System.out.println("Nós temos os seguintes sabores das Pizzas disponíveis:");

        for (String sabor : sabores) {
            System.out.println(sabor);
        }
    }
    // Método para exibir os tamanhos disponíveis
    public static void mostrarTamanhos() {
        System.out.println("\nTamanhos disponíveis:");

        for (String tamanho : tamanhos) {
            System.out.println(tamanho);
        }
    }
}
